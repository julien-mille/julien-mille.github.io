import numpy as np
import torch
from torch import nn
from torch import autograd
import math
from torch.utils.data import DataLoader
from tiny_imagenet_dataset import TinyImageNetDatasetTrain
from tiny_imagenet_dataset import TinyImageNetDatasetTest
import cv2
import sys

img_dir = './data'
datasetTrain = TinyImageNetDatasetTrain(img_dir)
loaderTrain = DataLoader(datasetTrain, shuffle = True, batch_size = 1)

datasetTest = TinyImageNetDatasetTest(img_dir)
loaderTest = DataLoader(datasetTest, shuffle = True, batch_size = 1)

for i, datum in enumerate(loaderTrain):
    img, idclass = datum
    # TODO...
